import { User } from "../entity/User";
import { StaffRepository } from "../repos/StaffRepository";

export class StaffService {

    private staffRepo : StaffRepository;

    constructor() {
        this.staffRepo = new StaffRepository()
}
    
    public toValidateEmail(email: string): void {
        const emailRegex: RegExp = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          throw new Error("E-mail inválido.");
        }
    }

    public async toListCustomer() : Promise<User[]> {
        return await this.staffRepo.listCustomers();
    }

    public async toSearchCustomerForID(id : number) : Promise<User[]> {
        let list : User[] = [];

        list =  await this.staffRepo.searchCustomersForID(id);

        if(list.length == 0)
        {
            throw new Error('Cliente nãao encontrado.');
        }

        return list;
    }   

    public async toInsertCustomers(name_User : string, nick_User : string, email_User : string, password_User : string) {
        this.toValidateEmail(email_User);

        await this.staffRepo.insertCustomers(name_User, nick_User, email_User, password_User)
    }

}