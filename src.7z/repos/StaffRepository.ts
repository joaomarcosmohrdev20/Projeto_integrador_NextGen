import { Pool } from "pg"
import { Database } from "./Database";
import { User } from "../entity/User";
import { Products } from "../entity/Products";

export class StaffRepository { 
    private pool : Pool;

    constructor() {
        this.pool = Database.startConection();
    }

    //#region Customers
    async listCustomers() : Promise<User[]> {
        const query = "Select * from Schema1.users";
        const result = await this.pool.query(query);

        let listOfUsers : User[] = [];

        
        for(const row of result.rows){
            const user = new User(row.id_User, row.name_User, row.nick_User, row.email_User, row.password_User);
            listOfUsers.push(user);            
        }             

        return listOfUsers;
    }   

    public async searchCustomersForID(id: number):Promise<User[]>{
        let query = "SELECT * FROM Schema1.users WHERE ID = $1"
        let result = await this.pool.query(query,[id])

        const listaOfUsers: User[] = [];

        for(const row of result.rows){
            const user = new User(row.id_User, row.name_User, row.nick_User, row.email_User, row.password_User);
            listaOfUsers.push(user);            
        }            

        return listaOfUsers;
    }   
    
    public async insertCustomers(name_User : string, nick_User : string, email_User : string, password_User : string){
        console.log("Cliente cadastrado com sucesso!");
        let query = "INSERT INTO Schema1.users (user_realname, user_nickname, user_email, user_password) VALUES ($1,$2,$3,$4)"
        await this.pool.query(query,[name_User, nick_User, email_User, password_User]);     

    }

    //#endregion 

    //#region Products

     async listProducts() : Promise<Products[]> {
    
            const query = "Select * from Schema1.products";
            const result = await this.pool.query(query);
    
            console.table(result);
    
            let listOfProducts : Products[] = [];
    
            for(const row of result.rows) {
                const product = new Products(row.idProducts, row.nameProducts, row.priceProducts, row.platformProducts);
                listOfProducts.push(product);
            }
    
            return listOfProducts;
    
        }
    
        async searchProductsForID(id : number) : Promise<Products[]> {
    
            const query = "Select * from schema1.products where ID = $1"
            const result = await this.pool.query(query);
    
            const listOfProducts : Products[] = [];
    
            for(const row of result.rows) {
                const product = new Products(row.idProducts, row.nameProducts, row.priceProducts, row.platformProducts)
                listOfProducts.push(product);
            }
    
            return listOfProducts;
    
        }
    
        async insertProducts(id_products : number, name_products : string, price_products : number, platform_products : string) { 
    
            const query = "Insert into Schema1.products (id_products, name_products, price_products, platform_products) values($1,$2,$3,$4)"
            await this.pool.query(query,[id_products, name_products, price_products, platform_products])
        }
    //#endregion

}