import { StaffService } from "../service/StaffService";
import promptSync  from 'prompt-sync' 

export class StaffView { 
    private staffService : StaffService;
    private prompt : promptSync 

    constructor() {
        this.prompt = promptSync();
        this.staffService = new StaffService();
    }

    async controlMenu() {
        console.log("Bem-vindo à Next Gen!")
        let choiceStaff = this.prompt("Digite 1 para listar todos os clientes atuais, digite 2 para buscar qualquer cliente pelo ID do cliente, digite 3 para cadastrar novos clientes.");

        switch (choiceStaff) {
            case "1":
                console.table(await this.staffService.toListCustomer());
                this.controlMenu();
                break;
            case "2": 
                let idCustomer = this.prompt("Qual o ID do cliente?");
                await this.staffService.toSearchCustomerForID(idCustomer);
                await this.controlMenu();
            
            case "3":
                let insertRealNameCustomer = this.prompt("Qual o nome real do cliente?");
                let insertNickNameCustomer = this.prompt("Qual o apelido do cliente?");
                let insertEmailCustomer = this.prompt("Qual o e-mail do cliente?");
                let insertPasswordCustomer = this.prompt("Qual a senha da conta do cliente?");
                this.staffService.toValidateEmail(insertEmailCustomer);
                await this.staffService.toInsertCustomers(insertRealNameCustomer, insertNickNameCustomer, insertEmailCustomer, insertPasswordCustomer);  
                this.controlMenu();  
            
            default:
                console.log("Não funcionou.");
                break;
        }
    }
}