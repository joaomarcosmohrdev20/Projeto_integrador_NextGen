import { StaffService } from "./service/StaffService";
import { StaffView } from "./View/StaffView";

const staffView = new StaffView;
const staffService = new StaffService;

staffView.controlMenu();